const prices = {"1 Hour":3,"3 Hours":7,"24 Hours":20};
let mxnRate = 19;
let stripe;
let elements;
let paymentData;
const heroImages = [
  "https://images.unsplash.com/photo-1510097467424-192d713fd8b2?auto=format&fit=crop&w=1600&q=80",
  "https://images.unsplash.com/photo-1552074284-5e88ef1aef18?auto=format&fit=crop&w=1600&q=80",
  "https://images.unsplash.com/photo-1588450130710-c4ac9fbd7a14?auto=format&fit=crop&w=1600&q=80"
];
let heroIndex = 0;
function rotateHero(){const hero=document.querySelector(".hero");if(!hero)return;hero.style.backgroundImage=`linear-gradient(rgba(0,30,70,.35),rgba(0,30,70,.35)),url('${heroImages[heroIndex]}')`;heroIndex=(heroIndex+1)%heroImages.length;}
rotateHero();setInterval(rotateHero,5000);
async function loadRate(){const cacheKey="bw_usd_mxn";try{const cached=JSON.parse(localStorage.getItem(cacheKey));if(cached&&Date.now()-cached.time<12*60*60*1000)mxnRate=cached.rate;const res=await fetch("https://api.frankfurter.app/latest?from=USD&to=MXN",{cache:"no-store"});const data=await res.json();if(data.rates&&data.rates.MXN){mxnRate=data.rates.MXN;localStorage.setItem(cacheKey,JSON.stringify({rate:mxnRate,time:Date.now()}));}}catch(e){}updatePricing();}
function mxn(usd){return "$"+(usd*mxnRate).toFixed(2)+" MXN";}
function updatePricing(){document.getElementById("mxn1").textContent=mxn(3);document.getElementById("mxn3").textContent=mxn(7);document.getElementById("mxn24").textContent=mxn(20);document.getElementById("rateStatus").textContent="Live Exchange Rate: 1 USD ≈ "+mxnRate.toFixed(2)+" MXN";updateSummary();}
function updateSummary(){const duration=document.getElementById("duration").value;const usd=prices[duration];document.getElementById("summaryDuration").textContent=duration;document.getElementById("summaryUsd").textContent="$"+usd.toFixed(2)+" USD";document.getElementById("summaryMxn").textContent=mxn(usd);}
document.getElementById("duration").addEventListener("change",updateSummary);loadRate();
async function getStripe(){if(stripe)return stripe;const res=await fetch("/config");const config=await res.json();if(!config.publishableKey)throw new Error("Stripe publishable key is missing in Render environment variables.");stripe=Stripe(config.publishableKey);return stripe;}
function collectData(){const duration=document.getElementById("duration").value;return{amount:prices[duration],duration,checkin:document.getElementById("checkin").value,customerName:document.getElementById("customerName").value,customerEmail:document.getElementById("customerEmail").value,customerPhone:document.getElementById("customerPhone").value,tagNumber:document.getElementById("tagNumber").value};}
document.getElementById("startPayment").addEventListener("click",async()=>{const form=document.getElementById("bookingForm");if(!form.reportValidity())return;const msg=document.getElementById("paymentMessage");try{paymentData=collectData();await getStripe();const res=await fetch("/create-payment-intent",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(paymentData)});const data=await res.json();if(data.error)throw new Error(data.error);elements=stripe.elements({clientSecret:data.clientSecret});const paymentElement=elements.create("payment");paymentElement.mount("#payment-element");document.getElementById("paymentForm").classList.remove("hidden");msg.textContent="";}catch(e){msg.textContent=e.message;}});
document.getElementById("paymentForm").addEventListener("submit",async(e)=>{e.preventDefault();const msg=document.getElementById("paymentMessage");msg.textContent="Processing payment...";const result=await stripe.confirmPayment({elements,redirect:"if_required"});if(result.error)msg.textContent=result.error.message;else msg.textContent="Payment successful. Receipt and confirmations will be sent automatically.";});