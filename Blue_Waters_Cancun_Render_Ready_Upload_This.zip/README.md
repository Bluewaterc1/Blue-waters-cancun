# Blue Waters Cancun Parking

Upload these files to GitHub at the top level of the repository.

Required top-level files:
- package.json
- server.js
- .env.example
- README.md
- public/

Render settings:
- Runtime: Node
- Build Command: npm install
- Start Command: npm start
- Root Directory: leave blank

Do not upload a `.env` file with real secrets to GitHub. Add secrets in Render Environment Variables.
